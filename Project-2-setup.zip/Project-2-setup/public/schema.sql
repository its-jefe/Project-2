DROP DATABASE IF EXISTS restaruant_db;

CREATE DATABASE restaruant_db;

